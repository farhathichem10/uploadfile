import { ImgComponent } from './img/img.component';
import { CatComponent } from './page/cat/cat.component';
import { ExampleeComponent } from './examplee/examplee.component';
import { Nav44Component } from './page/nav44/nav44.component';
import { Ac2Component } from './page/ac2/ac2.component';
import { NavComponent } from './page/nav/nav.component';
import { UpdateprodComponent } from './page/updateprod/updateprod.component';
import { CategoryComponent } from './page/category/category.component';
import { AddproductComponent } from './page/addproduct/addproduct.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './page/home/home.component';
import { LoginComponent } from './page/login/login.component';
import { DetailComponent } from './page/detail/detail.component';
import { NavigationComponent } from './page/navigation/navigation.component';
import { AcComponent } from './page/ac/ac.component';
import { UpdatecatComponent } from './page/updatecat/updatecat.component';
import { AuthService } from './service/auth.service';
import { AddeComponent } from './page/adde/adde.component';



const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'home', component: HomeComponent,canActivate:[AuthService]},
  {path:'addproduct', component:AddproductComponent,canActivate:[AuthService]},
  {path:'addcat', component:CategoryComponent,canActivate:[AuthService]},
  {path:'updateprod/:id', component:UpdateprodComponent,canActivate:[AuthService]},
  {path:'nav', component:NavComponent,canActivate:[AuthService]},
  { path: 'home/:id', component: DetailComponent,canActivate:[AuthService]},
  { path: 'adde', component: AddeComponent},
  {path:'nav22/:id', component:NavigationComponent,canActivate:[AuthService]},
  {path:'ac', component:AcComponent},
  {path:'ac/:id', component:Ac2Component},
  {path:'nav44/:id', component:Nav44Component},
  {path:'ex', component:ExampleeComponent,canActivate:[AuthService]},
  {path:'cat', component:CatComponent,canActivate:[AuthService]},
  {path:'updatecat/:id', component:UpdatecatComponent,canActivate:[AuthService]},
  {path:'img', component:ImgComponent,canActivate:[AuthService]}




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],


})
export class AppRoutingModule { }


