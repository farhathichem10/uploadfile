import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './page/login/login.component';
import { HomeComponent } from './page/home/home.component';
import { NgxWebstorageModule } from 'ngx-webstorage';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { AddproductComponent } from './page/addproduct/addproduct.component';
import { CategoryComponent } from './page/category/category.component';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UpdateprodComponent } from './page/updateprod/updateprod.component';
import { NavComponent } from './page/nav/nav.component';
import { DetailComponent } from './page/detail/detail.component';
import { NavigationComponent } from './page/navigation/navigation.component';
import { AcComponent } from './page/ac/ac.component';
import { Ac2Component } from './page/ac2/ac2.component';
import { Nav44Component } from './page/nav44/nav44.component';
import { ExampleeComponent } from './examplee/examplee.component';
import { CatComponent } from './page/cat/cat.component';
import { UpdatecatComponent } from './page/updatecat/updatecat.component';
import { ImgComponent } from './img/img.component';
import { AddeComponent } from './page/adde/adde.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AddproductComponent,
    CategoryComponent,
    UpdateprodComponent,
    NavComponent,
    DetailComponent,
    NavigationComponent,
    AcComponent,
    Ac2Component,
    Nav44Component,
    ExampleeComponent,
    CatComponent,
    UpdatecatComponent,
    ImgComponent,
    AddeComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxWebstorageModule.forRoot(),
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
