import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { PictureService } from 'src/app/service/picture.service';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-ac2',
  templateUrl: './ac2.component.html',
  styleUrls: ['./ac2.component.css']
})
export class Ac2Component implements OnInit {

  prod:any=[]
  idd:number
  cat:any=[]
  id:number
  prod2:any=[]

  constructor( private productService: ProductService, private pictureService: PictureService,private catservice:CategoryService,private ac:ActivatedRoute) {
    this.idd=this.ac.snapshot.params['id'];

  }

  ngOnInit() {
    this.getallcat()
this.getallproducts
    this.getproducts()
  }
  deletea(id)
  {
  this.productService.deleteproduct(id).subscribe(
    data=>{this.getallproducts()},
    erre=>{}
  )
  }
  getallproducts(){
    this.productService.getAllProducts().subscribe(value => {
      this.prod2 = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getproducts(){
    this.productService.getproductbycat(this.idd).subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getallcat(){
    this.catservice.getcategories().subscribe(value => {
      this.cat = value;
      console.log(this.prod);
    },error => console.log(error))
  }



  }
