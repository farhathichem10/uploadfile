import { Router, ActivatedRoute } from '@angular/router';
import { ProductService } from './../../service/product.service';
import { CategoryService } from './../../service/category.service';
import { Component, OnInit } from '@angular/core';
import { NotifyService } from 'src/app/service/notify.service';

@Component({
  selector: 'app-updatecat',
  templateUrl: './updatecat.component.html',
  styleUrls: ['./updatecat.component.css']
})
export class UpdatecatComponent implements OnInit {
id:number
cat:any
  constructor(private serv:CategoryService,private serv2:ProductService,private route:Router,private ac:ActivatedRoute,private toaster:NotifyService) {
    this.id=this.ac.snapshot.params['id'];
  }

  ngOnInit()  {
    this.getcatid()
  }
  getcatid(){this.serv.getcat(this.id).subscribe(
    data => { this.cat=data
      console.log(data) },
    err => { console.log})}
    updatecat() {
      this.serv.updateproduct( this.cat)
        .subscribe(
          data=>{ this.toaster.showSuccess("La catégorie à été bien modifier !!", "MODIFICATION")
            this.route.navigate(['/cat'])},

erre=>{}
);


}


}
