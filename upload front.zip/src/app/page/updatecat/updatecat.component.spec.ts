import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecatComponent } from './updatecat.component';

describe('UpdatecatComponent', () => {
  let component: UpdatecatComponent;
  let fixture: ComponentFixture<UpdatecatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatecatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatecatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
