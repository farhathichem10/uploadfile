import { CategoryService } from './../../service/category.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from './../../service/product.service';
import { Component, OnInit } from '@angular/core';
import { NotifyService } from 'src/app/service/notify.service';

@Component({
  selector: 'app-updateprod',
  templateUrl: './updateprod.component.html',
  styleUrls: ['./updateprod.component.css']
})
export class UpdateprodComponent implements OnInit {
  product: any;
  id: number;
  categories: any = [];
  products:any=[];
  category: any = {"id": ""};
  productImage: File[];
  ChoosenCategory: any = {};
  prodsChoosenLength:number=0;
  pictureURL: string = "http://127.0.0.1:8080/api/getfile/"
  deleteMessage: string = "";
  deleteidProd:number=0;
  page=1;
  pageSize=10;
  private updateform: any;
  private updateformOLD: any;
  constructor( private serv: ProductService,private route:Router,private ac: ActivatedRoute ) {
    this.id = this.ac.snapshot.params['id'];
  }

  ngOnInit(): void {
    this.getproducts();
     this.getProduct(this.id);
  }

  getProduct (id:number) {
    this.serv.getproductbyid(id).subscribe(value => {
      this.product =value
      console.log(this.product.categories.id);
    })
  }


  register(form) {
    this.product = form.value;
    this.product.newPro=true;
    this.product.sale=true;
    this.category.id = this.product.category
    this.product.categories = this.category
    console.log(this.product)
    /*this.product.pictureUrl = "null"
    console.log(this.product)*/
  }


  onSubmit(id: number) {
    const formData = new FormData();
    for (let file of this.productImage){
    formData.append('file', file);
    this.serv.upload(formData, id).subscribe(
      (res) => console.log("done"),
      (err) => console.log(err)
    );
  }
  }

  onFileChange(event) {
    let files = event.target.files;
    console.log(files)
    if (files.length > 0) {
      this.productImage = files;
    }
  }


  onChangeSelectCategories(newValue) {
    console.log(newValue)
    this.categories.forEach(c => {
      if (c.id == newValue) {
        c.products=this.products;
        this.ChoosenCategory = c;
        this.prodsChoosenLength=c.length;
      }
    })
  }

  getproducts() {
    this.serv.getcategorieswithproducts().subscribe(value => {
      this.categories = value;
      console.log(this.categories);
    }, error => console.log(error))
  }
}
