import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
id:number
  constructor(private route:Router,private ac:ActivatedRoute) {
    this.id=this.ac.snapshot.params['id'];
   }

  ngOnInit() {
    if (this.id!=null){
      this.route.navigate(['/home/'+this.id])}
    }
  }


