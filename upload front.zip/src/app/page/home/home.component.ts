import { NavigationEnd, Router, RouterEvent } from '@angular/router';
import { CategoryService } from './../../service/category.service';
import { PictureService } from './../../service/picture.service';
import { ProductService } from './../../service/product.service';

import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { LocalStorage } from 'ngx-webstorage';
import { NotifyService } from 'src/app/service/notify.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  prod:any=[]
  idd:number
  cat:any=[]
  iddd:number
  active:any = 0;
  @Input() testdelay : Boolean = false
  s="true"


  constructor(private cd: ChangeDetectorRef,private productService: ProductService, private pictureService: PictureService,private catservice:CategoryService,private notify:NotifyService) {

  }

  ngOnInit() {

    this.getallcat()

   this.filter(0);


  }

  filter(id) {
    this.active = id;
    if (id == 0 ) {
      this.productService.getAllProducts().subscribe(value => {
        this.prod = value;
        console.log(this.prod);
      },error => console.log(error))
    }else {
    this.productService.getproductbycat(id).subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  }

  deletea(id)
  {
    if (window.confirm('Are sure you want to delete this product ?')){
  this.productService.deleteproduct(id).subscribe(
    data=>{this.notify.showInfo("Suppression","Le produit à été bien supprimer")
    this.getallproducts()},
    erre=>{}
  )}
  }
  getallproducts(){
    this.productService.getAllProducts().subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getallcat(){
    this.catservice.getcategories().subscribe(value => {
      this.cat = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  deletecat(){
    this.catservice.deletecategory(this.iddd).subscribe(value => {
     this.ngOnInit()
      console.log(this.prod);
    },error => console.log(error))
  }



  }



