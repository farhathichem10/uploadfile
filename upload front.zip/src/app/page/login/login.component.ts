import { UserService } from './../../service/user.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email:string;
  password:string;
  user : any;
  users:any=[];

  constructor(private serv:UserService,private local:LocalStorageService,private router:Router) { }

  ngOnInit() {
  }
  verif(){
this.serv.login(this.email,this.password).subscribe(
  data => {this.users=data;
    if(this.users.length>0){
      this.local.store("user",this.users[0]);
      this.router.navigate(["/home"])
    }else{

this.router.navigate(["/login"])

    }


  },
  err => { }
)


  }

}
