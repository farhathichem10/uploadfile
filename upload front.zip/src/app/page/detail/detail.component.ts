import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { PictureService } from 'src/app/service/picture.service';
import { ProductService } from 'src/app/service/product.service';
import { NotifyService } from 'src/app/service/notify.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {
  prod:any=[]
  idd:number
  cat:any=[]
  id:number
  iddd:number
  prod2:any=[]

  constructor( private productService: ProductService, private pictureService: PictureService,private catservice:CategoryService,private ac:ActivatedRoute,private notify:NotifyService) {
    this.idd=this.ac.snapshot.params['id'];

  }

  ngOnInit() {
    this.getallcat()
this.getallproducts
    this.getproducts()
  }
  deletea(id)
  {
    if (window.confirm('Are sure you want to delete this product ?')){
  this.productService.deleteproduct(id).subscribe(
    data=>{this.notify.showInfo("Suppression","Le produit à été bien supprimer")
    this.getallproducts()},

    erre=>{}
  )}
  }
  getallproducts(){
    this.productService.getAllProducts().subscribe(value => {
      this.prod2 = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getproducts(){
    this.productService.getproductbycat(this.idd).subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getallcat(){
    this.catservice.getcategories().subscribe(value => {
      this.cat = value;
      console.log(this.prod);
    },error => console.log(error))
  }




  }
