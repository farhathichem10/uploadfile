import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-nav44',
  templateUrl: './nav44.component.html',
  styleUrls: ['./nav44.component.css']
})
export class Nav44Component implements OnInit {

  id:number
  constructor(private route:Router,private ac:ActivatedRoute) {
    this.id=this.ac.snapshot.params['id'];
   }

  ngOnInit() {
    if (this.id!=null){
      this.route.navigate(['/ac/'+this.id])}
    }
  }

