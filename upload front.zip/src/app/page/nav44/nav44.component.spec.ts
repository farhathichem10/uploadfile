import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Nav44Component } from './nav44.component';

describe('Nav44Component', () => {
  let component: Nav44Component;
  let fixture: ComponentFixture<Nav44Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Nav44Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Nav44Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
