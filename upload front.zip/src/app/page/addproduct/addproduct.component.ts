import { Router } from '@angular/router';
import { ProductService } from './../../service/product.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {


  product: any;
  categories: any = [];
  products:any=[];
  category: any = {"id": ""};
  productImage: File[];
  ChoosenCategory: any = {};
  prodsChoosenLength:number=0;
  pictureURL: string = "http://127.0.0.1:8080/api/getfile/"
  deleteMessage: string = "";
  deleteidProd:number=0;
  page=1;
  pageSize=10;
  private updateform: any;
  private updateformOLD: any;
  constructor( private serv: ProductService,private route:Router ) {
  }

  ngOnInit(): void {
    this.getproducts();
    this.getallproducts();
  }



  add() {

    this.serv.addproduct(this.product).subscribe(value => {

      this.onSubmit(value["id"])
      this.route.navigate(["/home"])
    }, error => {

      console.log("error add")
    })

  }

  delete(){

    this.serv.deleteproduct(this.deleteidProd).subscribe(value => {

      this.getproducts();
      this.getallproducts();
    }, error => {

    })
  }
   update(){
     this.serv.updateproduct(this.updateform).subscribe(value => {
       console.log(value)
       this.getproducts()
       this.getallproducts();

     })
     if (this.productImage != undefined){
       this.onSubmit(this.updateform.id)
     }
   }
  updateProduct(prod:any,contentUpdate,idcategory:number){
    this.updateform=prod
    this.updateformOLD=prod
    this.category.id=idcategory
    this.updateform.category=this.category
    console.log(this.updateform)

  }
  deleteProduct(id:number,name: string, contentedelete) {
    this.deleteMessage = name;
    this.deleteidProd=id;

  }



  register(form) {
    this.product = form.value;
    this.product.newPro=true;
    this.product.sale=true

     this.category.id = this.product.category
    this.product.categories = this.category
    console.log(this.product)
    /*this.product.pictureUrl = "null"
    console.log(this.product)*/

    this.add()
  }

  onFileChange(event) {
    let files = event.target.files;
    console.log(files)
    if (files.length > 0) {
      this.productImage = files;
    }
  }

  onSubmit(id: number) {
    const formData = new FormData();
    for (let file of this.productImage){
    formData.append('file', file);
    this.serv.upload(formData, id).subscribe(
      (res) => console.log("done"),
      (err) => console.log(err)
    );
  }
  }

  getproducts() {
    this.serv.getcategorieswithproducts().subscribe(value => {
      this.categories = value
      console.log(this.categories)
    }, error => console.log(error))
  }
  getallproducts(){
    this.serv.getAllProducts().subscribe(value => {
      this.products = value;
      console.log(this.products);
    },error => console.log(error))
  }
  onChangeSelectCategories(newValue) {
    console.log(newValue)
    this.categories.forEach(c => {
      if (c.id == newValue) {
        c.products=this.products;
        this.ChoosenCategory = c;
        this.prodsChoosenLength=c.length;
      }
    })
  }




}
