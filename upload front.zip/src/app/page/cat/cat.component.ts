import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CategoryService } from 'src/app/service/category.service';
import { NotifyService } from 'src/app/service/notify.service';
import { PictureService } from 'src/app/service/picture.service';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {

  prod:any=[]
  idd:number
  cat:any=[]
  iddd:number

  constructor(private toastr: NotifyService, private productService: ProductService, private pictureService: PictureService,private catservice:CategoryService) {

  }

  ngOnInit() {
    this.getallcat()

    this.getallproducts();
  }
  deletea(id)
  {
  this.productService.deleteproduct(id).subscribe(
    data=>{this.getallproducts()},
    erre=>{}
  )
  }
  getallproducts(){
    this.productService.getAllProducts().subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getallcat(){
    this.catservice.getcategories().subscribe(value => {
      this.cat = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  deletecat(iddd){
    if (window.confirm('Are sure you want to delete this Abonnee ?')){
    this.catservice.deletecategory(iddd).subscribe(value => {
      this.toastr.showInfo("Suppression","La catégorie à été bien supprimer")
     this.ngOnInit()
      console.log(this.prod);
    },error => console.log(error))
  }}



  }



