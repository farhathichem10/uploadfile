import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { LocalStorage, LocalStorageService } from 'ngx-webstorage';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  @LocalStorage() user: any;
  constructor(private local: LocalStorageService,private route:Router) { }

  ngOnInit(): void {
  }
  deconnexion() {
    this.local.clear("user")
    this.route.navigate(['/login'])
}
}
