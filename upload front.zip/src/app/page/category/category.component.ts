import { Router } from '@angular/router';
import { CategoryService } from './../../service/category.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotifyService } from 'src/app/service/notify.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  public signupForm:  FormGroup;
  constructor(private serv:CategoryService,private route:Router,private notifyService:NotifyService) { }

  ngOnInit() {
    this.infoForm()
  }
  infoForm() {
    this.signupForm =new FormGroup({

        'name': new FormControl(null, [Validators.required, Validators.minLength(2)]),
        'description': new FormControl(null, [Validators.required, Validators.minLength(2)]),


      });
    }
    onSubmit() {
      if(!this.signupForm.invalid){
        this.addData();

      }}

      addData() {
        this.serv.save(this.signupForm.value).
        subscribe( data => {
          this.notifyService.showSuccess("La catégorie à été bien ajouter !!", "Enregistrement")



          this.route.navigate(['/cat']);
        });
      }
    }


