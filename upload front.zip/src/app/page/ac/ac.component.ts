import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { PictureService } from 'src/app/service/picture.service';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-ac',
  templateUrl: './ac.component.html',
  styleUrls: ['./ac.component.css']
})
export class AcComponent implements OnInit {

  prod:any=[]
  idd:number
  cat:any=[]

  constructor( private productService: ProductService, private pictureService: PictureService,private catservice:CategoryService) {

  }

  ngOnInit() {
    this.getallcat()

    this.getallproducts();
  }
  deletea(id)
  {
  this.productService.deleteproduct(id).subscribe(
    data=>{this.getallproducts()},
    erre=>{}
  )
  }
  getallproducts(){
    this.productService.getAllProducts().subscribe(value => {
      this.prod = value;
      console.log(this.prod);
    },error => console.log(error))
  }
  getallcat(){
    this.catservice.getcategories().subscribe(value => {
      this.cat = value;
      console.log(this.prod);
    },error => console.log(error))
  }



  }
