import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private baseUrl = 'http://127.0.0.1:8081/api';

  constructor(private http: HttpClient) {
  }

  save(info): Observable<Object> {
    return this.http.post(this.baseUrl + "/category", info)
  }

  getcategories() {
    return this.http.get(this.baseUrl + "/categories")
  }

  deletecategory(id: number) {
    return this.http.delete(this.baseUrl + "/category/" + id);
  }

  updateproduct(p: any) {
    return this.http.put(this.baseUrl + "/category", p)
  }
  getcat(id:number){
   return  this.http.get(this.baseUrl + "/category/"+id)

  }
}
