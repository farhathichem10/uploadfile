import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PictureService {


  private baseUrl = 'http://127.0.0.1:8081/api';

  constructor(private http: HttpClient) {
  }
  add(p,id){
    return this.http.post(this.baseUrl + "/upload/"+id, p)
  }
  delete(id){
    return this.http.delete(this.baseUrl + "/picture/" + id)
  }
  getImg(id:number){
    return this.http.get(this.baseUrl+"/img/"+id)
  }

}
