import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LocalStorageService } from 'ngx-webstorage';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private local:LocalStorageService,private route:Router) { }
  canActivate(){


    let user=this.local.retrieve("user");
    if(user){

      return true;

    }else{
      this.route.navigate(['/login']);
      return false;
    }
  }
}
