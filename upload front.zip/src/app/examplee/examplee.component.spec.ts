import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExampleeComponent } from './examplee.component';

describe('ExampleeComponent', () => {
  let component: ExampleeComponent;
  let fixture: ComponentFixture<ExampleeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExampleeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExampleeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
