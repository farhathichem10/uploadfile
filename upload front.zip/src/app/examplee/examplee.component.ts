import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-examplee',
  templateUrl: './examplee.component.html',
  styleUrls: ['./examplee.component.css']
})
export class ExampleeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
